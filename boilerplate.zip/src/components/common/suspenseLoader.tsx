const SuspenseLoader = () => {
    return(
        <div>
            suspense
        </div>
    )
}

export default SuspenseLoader
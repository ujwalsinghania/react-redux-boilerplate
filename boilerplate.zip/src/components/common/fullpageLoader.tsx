const FpLoader = () => {
    return(
        <div>
           ...
        </div>
    )
}

export default FpLoader
const apiUrl = 'http://localhost:3097/'

if(process.env.REACT_APP_ENV === ''){

}

export const API_BASE_URL = apiUrl
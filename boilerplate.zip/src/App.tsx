import { Suspense } from "react";
import { useQuery } from "react-query";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { getUser } from "./api/userApi";
import "./App.css";
import FpLoader from "./components/common/fullpageLoader";
import { ALL_ROUTES } from "./config/allRoutes";
import Home from "./containers/home/home";
import PrivateRoute from "./hoc/privateRoute";
import PublicRoute from "./hoc/pulicRoute";

function App() {
  const { data, isLoading } = useQuery("user", getUser, {
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    retry: false,
    enabled: localStorage.getItem("token") ? true : false,
  });

  if (isLoading) {
    return <FpLoader />;
  }

  return (
    <BrowserRouter>
      <div className="App">
        <Switch>
          <Route exact path="/" component={Home} />
          {ALL_ROUTES.map((route) =>
            route.isPrivate ? (
              <PrivateRoute key={route.path} {...route}>
                <route.component />
              </PrivateRoute>
            ) : (
              <PublicRoute key={route.path} {...route}>
                <route.component />
              </PublicRoute>
            )
          )}
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;

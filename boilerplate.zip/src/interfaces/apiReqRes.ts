export interface LoginReq{
    identifier: string;
    password: string;
}
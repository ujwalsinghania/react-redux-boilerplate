import { request } from "./axiosUtils";
import { logout, setMe } from "../redux/reducers/userReducer";
import store from "../redux/store";
import { LoginReq } from "./../interfaces/apiReqRes";
import { API_URLS } from "../config";

export const loginUser = async (data: LoginReq) => {
  let resp: any = await request({
    url: API_URLS.LOGIN,
    method: "post",
    data,
    isAuth: false,
  });
  if (resp?.data) {
    localStorage.setItem("token", resp.data.token);
    await getUser();
  }
  return resp;
};

export const getUser = async () => {
  let resp = await request({
    url: API_URLS.ME,
    method: "get",
    isAuth: true,
  });
  store.dispatch(setMe(resp.data));
  return resp;
};

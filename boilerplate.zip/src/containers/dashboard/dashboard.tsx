const Dashboard = () => {
  return (
    <div>
      <h6>Dashboard</h6>
    </div>
  );
};

export default Dashboard;
